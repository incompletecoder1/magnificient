
#!/bin/bash
chmod a+x engines/stockfish_13_linux_x64_modern
ls engines -l
python lichess-bot.py
