#!/bin/bash
chmod +x engines/engine_name
python lichess-bot.py

# replace engine_name with the name of your engine
